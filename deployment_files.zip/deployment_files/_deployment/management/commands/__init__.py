"""
Django must wait for DB to be ready
"""
